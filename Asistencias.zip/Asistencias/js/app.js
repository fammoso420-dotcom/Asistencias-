// ============================================================
// Asistencias — lógica de la aplicación
// ============================================================

const STATUS = {
  presente: 'Presente',
  falta: 'Falta',
  retardo: 'Retardo',
  permiso: 'Permiso'
};

let employeesCache = []; // [{id, name, role}]
let todayStr = '';

// ---------- Guardia de sesión ----------
auth.onAuthStateChanged((user) => {
  if (!user) {
    window.location.href = 'index.html';
    return;
  }
  document.getElementById('user-email').textContent = user.email;
  init();
});

document.getElementById('logout-btn').addEventListener('click', () => auth.signOut());

// ---------- Utilidades de fecha ----------
function pad(n) { return String(n).padStart(2, '0'); }

function dateToStr(d) {
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

function monthOf(dateStr) {
  return dateStr.slice(0, 7); // YYYY-MM
}

function formatDateLong(dateStr) {
  const [y, m, d] = dateStr.split('-').map(Number);
  const date = new Date(y, m - 1, d);
  return date.toLocaleDateString('es-MX', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
}

// ---------- Inicialización ----------
function init() {
  const now = new Date();
  todayStr = dateToStr(now);
  document.getElementById('today-label').textContent = now.toLocaleDateString('es-MX', { day: 'numeric', month: 'long', year: 'numeric' });
  document.getElementById('attendance-date-label').textContent = formatDateLong(todayStr);

  const monthInput = document.getElementById('report-month');
  monthInput.value = `${now.getFullYear()}-${pad(now.getMonth() + 1)}`;

  setupTabs();
  setupEmployeeForm();
  document.getElementById('report-load-btn').addEventListener('click', loadReport);

  listenEmployees();
}

// ---------- Tabs ----------
function setupTabs() {
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
      btn.classList.add('active');
      document.getElementById(btn.dataset.view).classList.add('active');
      if (btn.dataset.view === 'view-reports') loadReport();
    });
  });
}

// ---------- Empleados ----------
function listenEmployees() {
  db.collection('employees').orderBy('name').onSnapshot((snap) => {
    employeesCache = snap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    renderEmployeeTable();
    renderPunchGrid();
    renderReportEmployeeOptions();
  });
}

function setupEmployeeForm() {
  document.getElementById('employee-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const name = document.getElementById('emp-name').value.trim();
    const role = document.getElementById('emp-role').value.trim();
    if (!name) return;
    await db.collection('employees').add({
      name, role,
      createdAt: firebase.firestore.FieldValue.serverTimestamp()
    });
    e.target.reset();
  });
}

function renderEmployeeTable() {
  const body = document.getElementById('employee-table-body');
  const empty = document.getElementById('employee-empty');
  document.getElementById('employee-count-label').textContent =
    employeesCache.length === 1 ? '1 empleado' : `${employeesCache.length} empleados`;

  if (employeesCache.length === 0) {
    body.innerHTML = '';
    empty.style.display = 'block';
    return;
  }
  empty.style.display = 'none';

  body.innerHTML = employeesCache.map(emp => `
    <tr>
      <td>${escapeHtml(emp.name)}</td>
      <td>${escapeHtml(emp.role || '—')}</td>
      <td><button class="btn-ghost" style="padding:5px 10px;" onclick="removeEmployee('${emp.id}')">Eliminar</button></td>
    </tr>
  `).join('');
}

async function removeEmployee(id) {
  if (!confirm('¿Eliminar a este empleado? Su historial de asistencia se conservará.')) return;
  await db.collection('employees').doc(id).delete();
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str || '';
  return div.innerHTML;
}

// ---------- Registrar asistencia (tarjeta de ponchado del día) ----------
let todayAttendance = {}; // employeeId -> {status, time}

function renderPunchGrid() {
  const grid = document.getElementById('punch-grid');
  const empty = document.getElementById('attendance-empty');

  if (employeesCache.length === 0) {
    grid.innerHTML = '';
    empty.style.display = 'block';
    return;
  }
  empty.style.display = 'none';

  grid.innerHTML = employeesCache.map(emp => `
    <div class="punch-card" id="punch-${emp.id}">
      <div class="punch-name">${escapeHtml(emp.name)}</div>
      <div class="punch-role">${escapeHtml(emp.role || '—')}</div>
      <div class="punch-status-row">
        ${Object.keys(STATUS).map(key => `
          <button class="status-btn" data-status="${key}" onclick="markAttendance('${emp.id}','${key}')">${STATUS[key]}</button>
        `).join('')}
      </div>
      <div class="punch-time" id="punch-time-${emp.id}"></div>
    </div>
  `).join('');

  loadTodayAttendance();
}

function loadTodayAttendance() {
  db.collection('attendance')
    .where('date', '==', todayStr)
    .onSnapshot((snap) => {
      todayAttendance = {};
      snap.docs.forEach(doc => {
        const data = doc.data();
        todayAttendance[data.employeeId] = data;
      });
      employeesCache.forEach(emp => updatePunchCardUI(emp.id));
    });
}

function updatePunchCardUI(empId) {
  const card = document.getElementById(`punch-${empId}`);
  if (!card) return;
  const record = todayAttendance[empId];
  card.querySelectorAll('.status-btn').forEach(btn => {
    btn.classList.remove('sel-presente', 'sel-falta', 'sel-retardo', 'sel-permiso');
    if (record && btn.dataset.status === record.status) {
      btn.classList.add(`sel-${record.status}`);
    }
  });
  const timeEl = document.getElementById(`punch-time-${empId}`);
  if (timeEl) {
    timeEl.textContent = record ? `registrado ${record.time || ''}` : '';
  }
}

async function markAttendance(empId, status) {
  const now = new Date();
  const time = `${pad(now.getHours())}:${pad(now.getMinutes())}`;
  const docId = `${empId}_${todayStr}`;
  await db.collection('attendance').doc(docId).set({
    employeeId: empId,
    date: todayStr,
    month: monthOf(todayStr),
    status,
    time,
    updatedAt: firebase.firestore.FieldValue.serverTimestamp()
  });
}

// ---------- Reportes mensuales ----------
function renderReportEmployeeOptions() {
  const sel = document.getElementById('report-employee');
  const current = sel.value;
  sel.innerHTML = '<option value="">Todos</option>' +
    employeesCache.map(emp => `<option value="${emp.id}">${escapeHtml(emp.name)}</option>`).join('');
  sel.value = current;
}

async function loadReport() {
  const month = document.getElementById('report-month').value; // YYYY-MM
  const empId = document.getElementById('report-employee').value;
  if (!month) return;

  let query = db.collection('attendance').where('month', '==', month);
  if (empId) query = query.where('employeeId', '==', empId);

  const snap = await query.get();
  const records = snap.docs.map(d => d.data()).sort((a, b) => a.date.localeCompare(b.date));

  renderReportSummary(records);
  renderReportTable(records);
}

function renderReportSummary(records) {
  const counts = { presente: 0, falta: 0, retardo: 0, permiso: 0 };
  records.forEach(r => { if (counts[r.status] !== undefined) counts[r.status]++; });

  const container = document.getElementById('report-summary');
  container.innerHTML = Object.keys(STATUS).map(key => `
    <div class="summary-stat">
      <div class="num">${counts[key]}</div>
      <div class="lbl">${STATUS[key].toLowerCase()}</div>
    </div>
  `).join('');
}

function renderReportTable(records) {
  const body = document.getElementById('report-table-body');
  const empty = document.getElementById('report-empty');

  if (records.length === 0) {
    body.innerHTML = '';
    empty.style.display = 'block';
    return;
  }
  empty.style.display = 'none';

  const nameOf = (id) => {
    const emp = employeesCache.find(e => e.id === id);
    return emp ? emp.name : '(empleado eliminado)';
  };

  body.innerHTML = records.map(r => `
    <tr>
      <td class="mono">${r.date}</td>
      <td>${escapeHtml(nameOf(r.employeeId))}</td>
      <td><span class="pill pill-${r.status}">${STATUS[r.status] || r.status}</span></td>
      <td class="mono">${r.time || '—'}</td>
    </tr>
  `).join('');
}
