// ============================================================
// CONFIGURACIÓN DE FIREBASE
// ============================================================
// 1. Ve a https://console.firebase.google.com y crea un proyecto.
// 2. Dentro del proyecto, agrega una "App web" (ícono </>).
// 3. Copia el objeto firebaseConfig que Firebase te muestra y
//    pégalo aquí abajo, reemplazando los valores de ejemplo.
// 4. En el panel de Firebase, activa:
//      - Authentication > Sign-in method > Correo/contraseña
//      - Firestore Database > Crear base de datos
// Ver README.md para el paso a paso completo.
// ============================================================

const firebaseConfig = {
  apiKey: "TU_API_KEY",
  authDomain: "TU_PROYECTO.firebaseapp.com",
  projectId: "TU_PROYECTO",
  storageBucket: "TU_PROYECTO.appspot.com",
  messagingSenderId: "TU_SENDER_ID",
  appId: "TU_APP_ID"
};

firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const db = firebase.firestore();
